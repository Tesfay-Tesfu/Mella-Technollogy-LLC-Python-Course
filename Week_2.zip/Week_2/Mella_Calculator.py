#############################
def add(x,y):# for Addition
  return x+y
#############################
def sub(x,y):# for Subtraction
  return x-y
##############################
def div(x,y):# for Division
  return x/y
##############################
def mult(x,y):# for Multiplication
  return x*y
